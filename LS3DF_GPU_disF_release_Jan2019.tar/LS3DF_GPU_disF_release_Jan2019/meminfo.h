void getmemsize(long long *mem);
void getusedmem(long long *mem);
void getfreemem(long long *mem);
