/* kenneth.roche@pnl.gov ; k8r@u.washington.edu */

#include <stdlib.h>

#include <stdio.h>

#include <papi.h>

#include <mpi.h>

/* 

   PAPI ::

   _TOT_IIS
   _TOT_INS
   _INT_INS
   _FP_INS
   _FMA_INS
   _VEC_INS
   _L2_DCM
 
*/

#define NUM_PAPI_EVENTS 3

void krp_rpt_init_( int * iam , MPI_Fint * commf , int * hw_counters , long long int * rcy  , long long int * rus , long long int * ucy , long long int * uus )

{

  MPI_Comm comm ;

  int i , j , npmpi ;

  int papi_events[ NUM_PAPI_EVENTS ] ;
  
  long long int papi_values[ NUM_PAPI_EVENTS + 4 ] ;
  
  /* long long int papi_real_cyc_0 , papi_virt_cyc_0 , papi_real_usec_0 , papi_virt_usec_0 ; */
  
  char * papi_event_name[] = { "PAPI_TOT_INS" , "PAPI_FP_INS" , "PAPI_L2_DCM" } ; 

  long long int * llbuf , llval ;

  /* PAPI exit results */

  PAPI_stop_counters( papi_values , *hw_counters ) ;

  papi_values[ *hw_counters ] = PAPI_get_real_cyc() - *rcy ;

  papi_values[ *hw_counters + 1 ] = PAPI_get_real_usec() - *rus ;

  papi_values[ *hw_counters + 2 ] = PAPI_get_virt_cyc() - *ucy ;

  papi_values[ *hw_counters + 3 ] = PAPI_get_virt_usec() - *uus ;

  /* learn a little about the calling environment */

  comm = MPI_Comm_f2c( *commf ) ;

  MPI_Comm_size( comm , &npmpi ) ;

  if ( *iam == 0 ) 
    
    {
      
      if ( ( llbuf = malloc( sizeof( long long int ) * npmpi ) ) == NULL ) 
	
	{
	  
	  npmpi = -1 ;
	  
	  MPI_Abort( comm , npmpi ) ;
	  
	}
          
      printf( "\n" ) ; 

    }

  for ( i = 0 ; i < *hw_counters ; i++ ) 
    
    {
      
      llval = 0LL ;
      
      MPI_Gather( &papi_values[ i ] , 1 , MPI_LONG_LONG , llbuf , 1 , MPI_LONG_LONG , 0 , comm ) ;
      
      if ( *iam == 0 ) 

        { /* report some profile information */
          
          for ( j = 0 ; j < npmpi ; j++ )
            
            llval += llbuf[ j ] ;
          
          printf("\t%s :\tTot[ %lld ]\tRt[ %lld ]\n", papi_event_name[ i ] , llval , papi_values[ i ] ) ; 

        }
      
      MPI_Barrier( comm ) ;
      
    }

  if ( *iam == 0 )
    
    {
      
      printf( "\tPAPI_real_cyc = %lld" , papi_values[ *hw_counters ] ) ;
      
      printf( "\tPAPI_real_usec = %lld\n" , papi_values[ *hw_counters + 1 ] ) ;
      
      printf( "\tPAPI_user_cyc = %lld" , papi_values[ *hw_counters + 2 ] ) ;
      
      printf( "\tPAPI_user_usec = %lld\n" , papi_values[ *hw_counters + 3 ] ) ;
      
      free ( llbuf ) ; 

    }

  /* begin again PAPI profiling here */
  
  *hw_counters = PAPI_num_counters() ;

  for ( i = 0 ; i < ( int ) NUM_PAPI_EVENTS ; i++ )

    {

      if ( PAPI_event_name_to_code( papi_event_name[ i ] , &papi_events[ i ] ) != PAPI_OK )

        { 

          fprintf( stderr , "papi error[%s]\n" , papi_event_name[ i ] ) ; 

          if ( *hw_counters > i ) 

	    *hw_counters = i ; 

        }
      
    }
  
  if ( *hw_counters > NUM_PAPI_EVENTS ) 

    *hw_counters = NUM_PAPI_EVENTS ;

  MPI_Barrier( comm ) ;

  *rcy = PAPI_get_real_cyc() ; 

  *rus = PAPI_get_real_usec() ; 

  *ucy = PAPI_get_virt_cyc() ; 

  *uus = PAPI_get_virt_usec() ; 

  PAPI_start_counters( papi_events , *hw_counters ) ;
  
}
