/* kenneth.roche@pnl.gov ; k8r@u.washington.edu */

#include <stdlib.h>

#include <stdio.h>

#include <mpi.h>

#include <papi.h>

#define NUM_PAPI_EVENTS 3

void krp_rpt_( int * iam , MPI_Fint * commf , int * hw_counters , long long int * rcy  , long long int * rus , long long int * ucy , long long int * uus )

{

  MPI_Comm comm ;

  int i , j , npmpi ;

  int papi_events[ NUM_PAPI_EVENTS ] ;
  
  long long int papi_values[ NUM_PAPI_EVENTS + 4 ] ;
  
  /* long long int papi_real_cyc_0 , papi_virt_cyc_0 , papi_real_usec_0 , papi_virt_usec_0 ; */
  
  char * papi_event_name[] = { "PAPI_TOT_INS" , "PAPI_FP_INS" , "PAPI_L2_DCM" } ; 

  long long int * llbuf , llval ;

  /* learn a little about the calling environment */

  comm = MPI_Comm_f2c( *commf ) ;

  MPI_Comm_size( comm , &npmpi ) ;

  /* PAPI exit results */

  PAPI_stop_counters( papi_values , *hw_counters ) ;

  papi_values[ *hw_counters ] = PAPI_get_real_cyc() - *rcy ;

  papi_values[ *hw_counters + 1 ] = PAPI_get_real_usec() - *rus ;

  papi_values[ *hw_counters + 2 ] = PAPI_get_virt_cyc() - *ucy ;

  papi_values[ *hw_counters + 3 ] = PAPI_get_virt_usec() - *uus ;

  if ( *iam == 0 ) 
    
    {
      
      if ( ( llbuf = malloc( sizeof( long long int ) * npmpi ) ) == NULL ) 
	
	{
	  
	  npmpi = -1 ;

	  MPI_Abort( comm , npmpi ) ;
	  
	}
      
    }
  
  for ( i = 0 ; i < *hw_counters ; i++ ) 
    
    {
      
      llval = 0LL ;
      
      MPI_Gather( &papi_values[ i ] , 1 , MPI_LONG_LONG , llbuf , 1 , MPI_LONG_LONG , 0 , comm ) ;
      
      if ( *iam == 0 ) 
	
	{ /* report some profile information */
	  
	  for ( j = 0 ; j < npmpi ; j++ )
	    
	    llval += llbuf[ j ] ;
	  
	  printf( "\t%s :\tTot[ %lld ]\tRt[ %lld ]\n", papi_event_name[ i ] , llval , papi_values[ i ] ) ; 
	  
	}
      
      MPI_Barrier( comm ) ;
      
    }

  if ( *iam == 0 )
    
    {
      
      printf( "\tPAPI_real_cyc = %lld\n" , papi_values[ *hw_counters ] ) ;
      
      printf( "\tPAPI_real_usec = %lld\n" , papi_values[ *hw_counters + 1 ] ) ;
      
      printf( "\tPAPI_user_cyc = %lld\n" , papi_values[ *hw_counters + 2 ] ) ;
      
      printf( "\tPAPI_user_usec = %lld\n" , papi_values[ *hw_counters + 3 ] ) ;
      
      free ( llbuf ) ; 

    }

  MPI_Barrier( comm ) ;
  
}
