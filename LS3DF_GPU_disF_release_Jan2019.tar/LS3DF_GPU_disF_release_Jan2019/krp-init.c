/* kenneth.roche@pnl.gov ; k8r@u.washington.edu */

#include <stdlib.h>

#include <stdio.h>

#include <papi.h>

/* 

   PAPI ::

   _TOT_IIS
   _TOT_INS
   _INT_INS
   _FP_INS
   _FMA_INS
   _VEC_INS
   _L2_DCM
 
*/

#define NUM_PAPI_EVENTS 3

void krp_init_( int * iam , int * hw_counters , long long int * rcy  , long long int * rus , long long int * ucy , long long int * uus )

{

  int i ;

  const PAPI_hw_info_t *hwinfo = NULL ;

  int papi_events[ NUM_PAPI_EVENTS ] ;
  
  long long int papi_values[ NUM_PAPI_EVENTS + 4 ] ;
  
  /* long long int papi_real_cyc_0 , papi_virt_cyc_0 , papi_real_usec_0 , papi_virt_usec_0 ; */
  
  char * papi_event_name[] = { "PAPI_TOT_INS" , "PAPI_FP_INS" , "PAPI_L2_DCM" } ; 

  /* learn something about the system here */
  
  if ( PAPI_library_init( PAPI_VER_CURRENT ) != PAPI_VER_CURRENT )
    
    exit( 1 ) ;
  
  if ( ( hwinfo = PAPI_get_hardware_info() ) == NULL )

    exit( 1 ) ; 
  
  if ( *iam == 0 )

    {

      printf( "\tInitialize PAPI Hardware Event Profilers\n" ) ;

      printf( "\t\tTotPEs()[%d]\n" , hwinfo->totalcpus ) ; /* Total number of CPU's in the entire system */

      printf( "\t\tMhz[%g]\n" , hwinfo->mhz ) ; /* Cycle time of this CPU, *may* be estimated at init time with a quick timing routine */

      printf( "\t\tnCPU-SMPnode()[%d]\n" , hwinfo->ncpu ); /* Number of CPU's in an SMP Node */

      printf( "\t\tnSMPnodes()[%d]\n" , hwinfo->nnodes ); /* Number of Nodes in the entire system */

      printf( "\t\t\tvendor string cpu[%s]\n" , hwinfo->vendor_string ); 

      printf( "\t\t\tmodel string cpu[%s]\n" , hwinfo->model_string ); 

      printf( "\t\t\tmodel number[%d]\n\n" , hwinfo->model ); 

      /*
	int vendor;                    Vendor number of CPU 
	char vendor_string[PAPI_MAX_STR_LEN];      Vendor string of CPU 
	int model;                     Model number of CPU 
	char model_string[PAPI_MAX_STR_LEN];       Model string of CPU 
	float revision;                Revision of CPU 
      */

    }

  /*

    typedef struct event_info {

    unsigned int event_code;                preset (0x8xxxxxxx) or native (0x4xxxxxxx) event code 

    unsigned int event_type;                event type or category for preset events only 

    unsigned int count;                     number of terms (usually 1) in the code and name fields
    - for presets, these terms are native events
    - for native events, these terms are register contents 

    char symbol[PAPI_HUGE_STR_LEN];        name of the event
    - for presets, something like PAPI_TOT_INS
    - for native events, something related to the vendor name
    - for perfmon2:opteron, these can get *very* long!

    char short_descr[PAPI_MIN_STR_LEN];     a description suitable for use as a label, typically only
    implemented for preset events 

    char long_descr[PAPI_HUGE_STR_LEN];     a longer description of the event
    - typically a sentence for presets
    - possibly a paragraph from vendor docs for native events 

    char derived[PAPI_MIN_STR_LEN];         name of the derived type
    - for presets, usually NOT_DERIVED
    - for native events, empty string 
    NOTE: a derived description string is available
    in papi_data.c that is currently not exposed to the user 

    char postfix[PAPI_MIN_STR_LEN];         string containing postfix operations; only defined for 
    preset events of derived type DERIVED_POSTFIX 

    unsigned int code[PAPI_MAX_INFO_TERMS]; array of values that further describe the event:
    - for presets, native event_code values
    - for native events, register values for event programming 

    char name[PAPI_MAX_INFO_TERMS]          names of code terms: 
    [PAPI_2MAX_STR_LEN];            - for presets, native event names, as in symbol, above
    - for native events, descriptive strings for each register
    value presented in the code array 

    char note[PAPI_HUGE_STR_LEN];           an optional developer note supplied with a preset event
    to delineate platform specific anomalies or restrictions
    NOTE: could also be implemented for native events.
    } PAPI_event_info_t;

  */

  /* begin PAPI profiling here */
  
  *hw_counters = PAPI_num_counters() ;

  for ( i = 0 ; i < ( int ) NUM_PAPI_EVENTS ; i++ )

    {

      if ( PAPI_event_name_to_code( papi_event_name[ i ] , &papi_events[ i ] ) != PAPI_OK )

	{ 

	  fprintf( stderr , "papi error[%s]\n" , papi_event_name[ i ] ) ; 

	  if ( *hw_counters > i ) *hw_counters = i ; 

	}
      
    }
  
  if( *hw_counters > NUM_PAPI_EVENTS ) 

    *hw_counters = NUM_PAPI_EVENTS ;

  *rcy = PAPI_get_real_cyc() ; 

  *rus = PAPI_get_real_usec() ; 

  *ucy = PAPI_get_virt_cyc() ; 

  *uus = PAPI_get_virt_usec() ; 

  PAPI_start_counters( papi_events , *hw_counters ) ;

}
